# 🚀 Hướng Dẫn Setup CMS cho tuminh.com.vn

## Tổng quan hệ thống

Sau khi setup xong, quy trình đăng bài của bạn sẽ là:
1. Vào `tuminh.com.vn/admin`
2. Đăng nhập → Viết bài → Publish
3. Bài tự động xuất hiện trên web trong ~1 phút

---

## BƯỚC 1: Tạo repo GitHub

1. Vào https://github.com → Đăng nhập (hoặc tạo tài khoản mới)
2. Nhấn **New repository** (nút dấu +)
3. Đặt tên repo: `tuminh-web` (hoặc tên bất kỳ)
4. Chọn **Public** (bắt buộc để Netlify đọc được)
5. Nhấn **Create repository**
6. **Ghi nhớ:** `username/tuminh-web` (ví dụ: `tuminh123/tuminh-web`)

---

## BƯỚC 2: Upload file lên GitHub

### Cách đơn giản nhất (kéo thả):

1. Vào repo vừa tạo trên GitHub
2. Nhấn **Add file** → **Upload files**
3. Kéo toàn bộ các file/folder sau vào:
   ```
   index.html
   netlify.toml
   admin/          (cả folder)
   posts/          (cả folder)
   ```
4. Nhấn **Commit changes**

> ⚠️ Giữ nguyên cấu trúc thư mục — `admin/` và `posts/` phải là folder, không phải file

---

## BƯỚC 3: Sửa config.yml — Điền tên repo của bạn

Mở file `admin/config.yml`, tìm dòng:
```yaml
repo: YOUR_GITHUB_USERNAME/YOUR_REPO_NAME
```

Thay bằng thông tin thật, ví dụ:
```yaml
repo: tuminh123/tuminh-web
```

Commit lại file này lên GitHub.

---

## BƯỚC 4: Kết nối Netlify với GitHub

1. Vào https://app.netlify.com → **Add new site** → **Import an existing project**
2. Chọn **GitHub** → Chọn repo `tuminh-web`
3. Cấu hình build:
   - **Build command:** (để trống)
   - **Publish directory:** `.` (dấu chấm)
4. Nhấn **Deploy site**
5. Vào **Domain settings** → Thêm domain `tuminh.com.vn`

---

## BƯỚC 5: Bật Netlify Identity (để đăng nhập /admin)

1. Trong Netlify Dashboard → **Integrations** → tìm **Identity**
2. Nhấn **Enable Identity**
3. Vào **Identity** → **Settings** → **Registration**: chọn **Invite only**
4. Nhấn **Invite users** → Nhập email của bạn → Gửi
5. Kiểm tra email → Nhấn link → Đặt mật khẩu

---

## BƯỚC 6: Kiểm tra

1. Vào `tuminh.com.vn/admin`
2. Đăng nhập bằng email/mật khẩu vừa tạo
3. Bạn sẽ thấy giao diện CMS với mục **"Bài viết Tri Thức"**
4. Thử tạo 1 bài viết mới → Publish → Chờ ~30 giây → Vào `/tri-thuc` kiểm tra

---

## Cách đăng bài mới (sau khi setup xong)

1. Vào `tuminh.com.vn/admin`
2. Click **"Bài viết Tri Thức"** → **"New Bài viết"**
3. Điền:
   - **Đường dẫn URL (slug):** `ten-bai-viet-cua-toi` (chữ thường, không dấu, dùng `-`)
   - **Tiêu đề:** Tiêu đề đầy đủ
   - **Danh mục:** Chọn từ dropdown
   - **Tóm tắt:** 1-2 câu mô tả (hiển thị ở trang danh sách)
   - **Ảnh thumbnail:** Upload ảnh bìa
   - **Nội dung:** Viết bài bằng Markdown
4. Nhấn **Publish** → Xong!

> ⚠️ **Lưu ý quan trọng:** Mỗi khi đăng bài mới, bạn cũng cần cập nhật file `posts/index.json` để bài hiện ra trong danh sách. Cách đơn giản nhất: thêm entry mới vào đầu mảng JSON theo cấu trúc:
> ```json
> {
>   "slug": "slug-cua-bai",
>   "title": "Tiêu đề bài viết",
>   "category": "Kinh nghiệm Đúc",
>   "summary": "Tóm tắt ngắn...",
>   "thumbnail": "/images/posts/ten-anh.jpg",
>   "read_time": "5 phút đọc"
> }
> ```

---

## Cấu trúc file sau khi hoàn chỉnh

```
tuminh-web/               ← GitHub repo
├── index.html            ← Web chính (đã cập nhật)
├── netlify.toml          ← Config Netlify
├── admin/
│   ├── index.html        ← Giao diện CMS tại /admin
│   └── config.yml        ← Cấu hình CMS (sửa repo ở đây)
├── posts/
│   ├── index.json        ← Danh sách bài (cập nhật mỗi khi đăng bài)
│   ├── nhiet-do-duc-kim-loai-khai-niem-nhiet-du.json
│   └── luyen-thep-bang-lo-ho-quang-dien-eaf.json
└── images/               ← Ảnh (giữ nguyên cấu trúc cũ)
    └── posts/            ← Ảnh upload qua CMS sẽ lưu tại đây
```

---

## Hỗ trợ

Nếu gặp lỗi, hãy kiểm tra:
- Console trình duyệt (F12 → Console) khi vào `/tri-thuc`
- File `posts/index.json` phải là JSON hợp lệ
- Slug trong `index.json` phải khớp chính xác với tên file `.json`
